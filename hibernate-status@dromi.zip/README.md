# gnome-shell-extension-hibernate-status
Gnome Shell extension that adds a hibernate/hybrid suspend button in Status menu.

This Gnome extension was first developped for a personal use and released. Unfortunatly, the original developper do not really use it anymore. Since many people were waiting it to be updated, it would be a good thing if someone else could maintain it !
Feel free to apply on Github !
